import gzip
import json
from pathlib import Path
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont
from film_open_motion import encode

source, output = map(Path, sys.argv[1:])
arms = ("old", "new")
labels = ("Current controller", "Stall-triggered approach")
rows = [json.loads(gzip.open(source / f"{arm}.jsonl.gz", "rt").readline()) for arm in arms]
paths = [sorted((source / arm).glob("*.jpg")) for arm in arms]
assert rows[0]["initial"] == rows[1]["initial"] and len(paths[0]) == len(paths[1])
font_path = "/System/Library/Fonts/Supplemental/Arial.ttf"
large = ImageFont.truetype(font_path, 28)
small = ImageFont.truetype(font_path, 21)


def frames():
    for i, (left, right) in enumerate(zip(*paths, strict=True)):
        t = i * 0.08
        panel = Image.new("RGB", (960, 442), "#122630")
        draw = ImageDraw.Draw(panel)
        for side, (path, label, row) in enumerate(zip((left, right), labels, rows, strict=True)):
            x = side * 482
            with Image.open(path) as native:
                cx, cy = native.width // 2, native.height // 2
                field = native.crop((cx - 335, cy - 240, cx + 335, cy + 240))
                panel.paste(field.resize((478, 342), Image.Resampling.LANCZOS), (x, 48))
            draw.text((x + 16, 9), label, font=large, fill="#f3f6f5")
            result = "Loose ball"
            capture = row["capture_s"]
            if capture is not None and t >= capture:
                robot = row["captured_by"]
                result = f"{robot['team'].title()} {robot['id']} secures at {capture:.2f} s"
            draw.text((x + 16, 401), result, font=small, fill="#f3f6f5")
        yield panel


output.mkdir(parents=True, exist_ok=True)
movie = output / "paired-replay.mp4"
encode(movie, frames(), 6.25)
subprocess.run(
    [
        "ffmpeg",
        "-v",
        "error",
        "-y",
        "-i",
        str(movie),
        "-filter_complex",
        "[0:v]scale=800:-2,split[a][b];[a]palettegen[p];[b][p]paletteuse=dither=bayer[out]",
        "-map",
        "[out]",
        "-loop",
        "0",
        str(output / "crowded-recovery.gif"),
    ],
    check=True,
)
