"""Ball-side challenge for the 5v5 Presser with a fitted angle and release motion."""

from dataclasses import dataclass
import math

from .carrier_motor import track_roller
from .model import Command, body_vector, wrap

ROBOT_GAP = 0.202
ROLLER = {"drive": 0.72, "step_v": 0.32, "grip": 5.0, "pivot": 5.0, "cap": 0.60}


@dataclass(frozen=True)
class BallSideTackle:
    angle_deg: float
    mouth_offset: float
    draw_speed: float
    flank: float

    def command(self, world, presser, carrier, observed, has_ball):
        ball = world.ball
        nx, ny = math.cos(carrier.yaw), math.sin(carrier.yaw)
        x, y = presser.x - carrier.x, presser.y - carrier.y
        side = math.copysign(1, nx * y - ny * x)
        cx, cy = observed[carrier.key]
        face = math.atan2(ball.y - presser.y, ball.x - presser.x)
        omega = 6 * wrap(face - presser.yaw)
        if has_ball:
            draw_x = cx + self.draw_speed * (nx - side * self.flank * ny)
            draw_y = cy + self.draw_speed * (ny + side * self.flank * nx)
            return track_roller(world, presser, (draw_x, draw_y), omega, ROLLER)

        direction = carrier.yaw + side * math.radians(self.angle_deg)
        goal_x = ball.x + self.mouth_offset * math.cos(direction)
        goal_y = ball.y + self.mouth_offset * math.sin(direction)
        dx, dy = goal_x - presser.x, goal_y - presser.y
        gain = min(4.2, 0.82 / max(0.01, math.hypot(dx, dy)))
        # If a challenger is level with or behind the carrier, go around its
        # ball-side hip before cutting across to the forward interception point.
        if nx * x + ny * y < 0.08 and math.hypot(x, y) < 0.42:
            dx, dy = 0.20 * nx - side * 0.24 * ny - x, 0.20 * ny + side * 0.24 * nx - y
        vx, vy = body_vector(cx + gain * dx, cy + gain * dy, presser.yaw)
        return Command(vx, vy, max(-5.0, min(5.0, omega)), 1)
