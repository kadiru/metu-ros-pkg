from dataclasses import asdict
import gzip
import json
import math
import os
from pathlib import Path
import traceback

import numpy as np
from controller import Supervisor
from roboturk.continuous_backend import ContinuousWebotsBackend
from roboturk.errt import ERRTFallback
from roboturk.five_play import open_play
from roboturk.five_roles import CFG, FiveRoles, TEAMS
from roboturk.model import Ball, Referee, Robot, RobotKey, World, possession
from roboturk.open_motion import Steering, observed_velocity
from roboturk.tackle import BallSideTackle
from roboturk.tackle_selector import TackleSelector
from roboturk.three_match import snapshot

root = Path(os.environ["CROWDED_FETCH_ROOT"])
work = Path(os.environ["CROWDED_FETCH_OUTPUT"])
sim = Supervisor()
backend = ContinuousWebotsBackend(sim, CFG)


def world_from(data):
    bots = tuple(
        Robot(RobotKey(**r["key"]), **{k: v for k, v in r.items() if k != "key"})
        for r in data["robots"]
    )
    return World(data["time"], bots, Ball(**data["ball"]), Referee.RUNNING, data["attack_sign"])


def play(case, enabled, record):
    w = backend.reset(world_from(case["initial"]))
    initial = asdict(w)
    keys = [r.key for r in w.robots]
    tactics = FiveRoles()
    if case["roles"]:
        tactics.previous = dict(zip(keys, case["roles"], strict=True))
    previous = {r.key: (r.x - CFG.dt * r.vx, r.y - CFG.dt * r.vy) for r in w.robots}
    owner = None
    streak = 0
    gap = float("inf")
    contacts = np.zeros(45, dtype=bool)
    contact_count = 0
    steering_ticks = 0
    snapshots = []
    first_touch = None
    capture_s = None
    fallback = ERRTFallback(case["seed"], "on-conflict", True)
    tackle = TackleSelector(tackle_profile, keeper_cover=True, keeper_lane=True)
    for tick in range(65):
        snapshots.append([*snapshot(w), backend.ball.getPosition()[2]])
        if record and tick % 2 == 0:
            f = work / ("new" if enabled else "old") / f"{tick // 2:04d}.jpg"
            f.parent.mkdir(exist_ok=True)
            sim.exportImage(str(f), 88)
        velocity = observed_velocity(w.robots, previous, CFG.dt)
        previous = {r.key: (r.x, r.y) for r in w.robots}
        motion = {}
        cmd, planned, roles, phases = open_play(
            w,
            tactics,
            weights,
            velocity,
            policy,
            trajectory=True,
            fallback=fallback,
            tackle=tackle,
            trace=motion,
            crowded_fetch=enabled,
        )
        steering_ticks += sum(m["mode"] == "crowded_fetch" for m in motion.values())
        w = backend.step(cmd)
        for k, _, _ in backend.last_kick_events:
            tactics.flight = planned.get(k)
        for sample in backend.last_substep_worlds:
            pos = np.asarray([(b.x, b.y) for b in sample.robots])
            distances = np.linalg.norm(pos[pairs[0]] - pos[pairs[1]], axis=1) - 2 * CFG.robot_radius
            gap = min(gap, float(distances.min()))
            touching = distances <= 0.001
            contact_count += int(np.count_nonzero(touching & ~contacts))
            contacts = touching
            holders = [k for k in keys if possession(sample, k, CFG)]
            new_owner = holders[0] if len(holders) == 1 else None
            if new_owner is not None and first_touch is None:
                first_touch = sample.time
            streak = (
                streak + 1
                if new_owner is not None and new_owner == owner
                else int(new_owner is not None)
            )
            owner = new_owner
            if streak * backend.basic_ms >= 240 and capture_s is None:
                capture_s = sample.time
                secured = owner
    return dict(
        seed=case["seed"],
        kind=case["kind"],
        initial=initial,
        trace=snapshots,
        captured=capture_s is not None,
        captured_by=asdict(secured) if capture_s is not None else None,
        capture_s=capture_s,
        first_touch=first_touch,
        body_contact_episodes=contact_count,
        minimum_gap_m=gap,
        steering_ticks=steering_ticks,
    )


try:
    values = json.loads((root / "policies/recipient_3v3_v1/selectors.json").read_text())
    weights = {t: np.array(values[str(901 + i)]) for i, t in enumerate(TEAMS)}
    policy = Steering(**json.loads((root / "policies/open_motion_v1/actor.json").read_text()))
    tackle_profile = BallSideTackle(
        **json.loads((root / "policies/ball_side_tackle_v1/actor.json").read_text())
    )
    pairs = np.triu_indices(10, 1)
    cases = json.loads((root / "runs/crowded-fetch-v1/cases.json").read_text())
    selected = os.environ.get("CROWDED_FETCH_CASE")
    if selected:
        cases = [c for c in cases if c["seed"] == int(selected)]
        x, y = (cases[0]["initial"]["ball"][a] for a in ("x", "y"))
        sim.getFromDef("CAMERA").getField("position").setSFVec3f([x, y, 5.0])
    result = {"old": [], "new": []}
    for index, case in enumerate(cases):
        for enabled in (False, True) if index % 2 == 0 else (True, False):
            row = play(case, enabled, bool(selected))
            result["new" if enabled else "old"].append(row)
            print(case["seed"], enabled, row["capture_s"], row["body_contact_episodes"], flush=True)
        assert result["old"][-1]["initial"] == result["new"][-1]["initial"]
    for name, rows in result.items():
        with gzip.open(work / f"{name}.jsonl.gz", "wt") as out:
            for row in rows:
                out.write(json.dumps(row, separators=(",", ":")) + "\n")
    sim.simulationQuit(0)
except Exception:
    traceback.print_exc()
    sim.simulationQuit(1)
