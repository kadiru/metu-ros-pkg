import gzip
import json
from pathlib import Path
from statistics import median
import sys

folder = Path(sys.argv[1])
versions = ("old", "new")
rows = {
    a: [json.loads(line) for line in gzip.open(folder / f"{a}.jsonl.gz", "rt")] for a in versions
}
assert len(rows["old"]) == len(rows["new"])
for old, new in zip(rows["old"], rows["new"], strict=True):
    assert old["seed"] == new["seed"] and old["initial"] == new["initial"]


def compact(row):
    data = {k: v for k, v in row.items() if k not in ("initial", "trace")}
    return data


def summary(cases):
    times = [r["capture_s"] for r in cases if r["captured"] and r["body_contact_episodes"] == 0]
    return dict(
        starts=len(cases),
        clean_captures=len(times),
        capture_s_median=round(median(times), 4) if times else None,
        clean_captures_within_one_second=sum(t <= 1 for t in times),
        body_contact_episodes=sum(c["body_contact_episodes"] for c in cases),
        minimum_gap_m=round(min(c["minimum_gap_m"] for c in cases), 5),
        approach_ticks=sum(c["steering_ticks"] for c in cases),
    )


def pair_summary(old, new):
    moved = [s for s in zip(old, new, strict=True) if s[0]["captured"] and s[1]["captured"]]
    return dict(
        faster=sum(b["capture_s"] + 0.002 < a["capture_s"] for a, b in moved),
        slower=sum(a["capture_s"] + 0.002 < b["capture_s"] for a, b in moved),
        shared_capture=len(moved),
        median_paired_delta_s=round(median(b["capture_s"] - a["capture_s"] for a, b in moved), 4)
        if moved
        else None,
        recovered_only_by_revision=[
            b["seed"] for a, b in zip(old, new, strict=True) if b["captured"] and not a["captured"]
        ],
        recovered_only_by_current=[
            a["seed"] for a, b in zip(old, new, strict=True) if a["captured"] and not b["captured"]
        ],
    )


report = {}
for kind in ("archive", "fresh"):
    groups = {a: [r for r in rows[a] if r["kind"] == kind] for a in versions}
    if groups["old"]:
        report[kind] = {a: summary(groups[a]) for a in versions}
        report[kind]["paired"] = pair_summary(groups["old"], groups["new"])
report["pairs"] = [
    {a: compact(r) for a, r in zip(versions, pair, strict=True)}
    for pair in zip(*rows.values(), strict=True)
]
if len(sys.argv) > 2:
    Path(sys.argv[2]).write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "pairs"}, indent=2))
