from dataclasses import asdict
import json
from roboturk.team import PassReceiveEnv
env = PassReceiveEnv()
starts = {}
for seed in range(32702000,32702200):
    env.reset(seed=seed)
    starts[seed] = asdict(env.world)
print(json.dumps(starts, sort_keys=True, separators=(',', ':')))
