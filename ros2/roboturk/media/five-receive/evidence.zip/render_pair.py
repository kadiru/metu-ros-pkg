"""Assemble a half-speed comparison from two native Webots recordings."""

import json
from pathlib import Path
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFont
from film_open_motion import encode

source, output = map(Path, sys.argv[1:])
trials = json.loads((source / "trials.json").read_text())
arms = ("baseline", "trained")
labels = ("Current first touch", "Trained first touch")
paths = [sorted((source / arm).glob("*.jpg")) for arm in arms]
rows = [trials[arm][0] for arm in arms]
assert rows[0]["initial"] == rows[1]["initial"]
font = "/System/Library/Fonts/Supplemental/Arial.ttf"
header = ImageFont.truetype(font, 27)
caption = ImageFont.truetype(font, 21)


def result_at(row, time):
    if row["goal"] is not None and time >= row["goal"]:
        return "Yellow scores"
    if row["shot"] is not None and time >= row["shot"]:
        return f"Shoots {row['shot_latency']:.2f} s after first touch"
    if row["bounce"] is not None and time >= row["bounce"]:
        return "Ball rebounds off the chassis"
    if row["first_touch"] is not None and time >= row["first_touch"]:
        return "Cushions the ball onto the roller"
    return "Incoming pass"


def frames():
    for i in range(max(map(len, paths))):
        time = i * 0.08
        panel = Image.new("RGB", (1120, 476), "#122630")
        draw = ImageDraw.Draw(panel)
        for side, (files, label, row) in enumerate(zip(paths, labels, rows, strict=True)):
            x = side * 562
            with Image.open(files[min(i, len(files) - 1)]) as native:
                camera = native.crop((389, 78, 1854, 1080))
                panel.paste(camera.resize((558, 382), Image.Resampling.LANCZOS), (x, 48))
            draw.text((x + 16, 9), label, font=header, fill="#f5f7f6")
            draw.text((x + 16, 444), result_at(row, time), font=caption, fill="#f5f7f6")
        yield panel


output.mkdir(parents=True, exist_ok=True)
movie = output / "paired-reception.mp4"
encode(movie, frames(), 6.25)
subprocess.run(
    [
        "ffmpeg",
        "-v",
        "error",
        "-y",
        "-i",
        str(movie),
        "-filter_complex",
        "[0:v]scale=900:-2,split[a][b];[a]palettegen[p];[b][p]paletteuse=dither=bayer[out]",
        "-map",
        "[out]",
        "-loop",
        "0",
        str(output / "first-touch.gif"),
    ],
    check=True,
)
