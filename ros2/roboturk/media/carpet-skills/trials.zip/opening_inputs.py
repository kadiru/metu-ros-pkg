"""Serialize the exact reset requests from the revision on PYTHONPATH, before integration."""
from dataclasses import asdict
import json
from roboturk.shoot import ShootEnv
from roboturk.team import PassReceiveEnv

starts = {}
for env, seed in ((ShootEnv(), 32600000), (PassReceiveEnv(), 32700000)):
    for i in range(40):
        env.reset(seed=seed+i)
        starts[seed+i] = asdict(env.world)
print(json.dumps(starts, sort_keys=True, separators=(',', ':')))
