"""Summarize matched native Webots receiver and dribble runs."""

import json
from pathlib import Path
from statistics import median
import sys

root, destination = map(Path, sys.argv[1:])
trials = json.loads((root / "eval/trials.json").read_text())
carry = json.loads((root / "carry/trials.json").read_text())
old, new = trials["baseline"], trials["trained"]
for a, b in zip(old, new, strict=True):
    assert a["seed"] == b["seed"] and a["initial"] == b["initial"]


def first_touch(rows):
    delays = [r["shot_latency"] for r in rows if r["shot_latency"] is not None]
    return dict(
        starts=len(rows),
        clean_first_touch=sum(r["clean_first_touch"] for r in rows),
        rebound=sum(r["bounce"] is not None for r in rows),
        goals=sum(r["goal"] is not None for r in rows),
        shots=len(delays),
        shots_within_650_ms=sum(t <= 0.65 for t in delays),
        clean_shots_within_650_ms=sum(
            r["clean_first_touch"] and r["shot_latency"] is not None and r["shot_latency"] <= 0.65
            for r in rows
        ),
        median_time_to_shot_s=round(median(delays), 4) if delays else None,
    )


delays = [
    b["shot_latency"] - a["shot_latency"]
    for a, b in zip(old, new, strict=True)
    if a["shot_latency"] is not None and b["shot_latency"] is not None
]
findings = {
    "receive": {arm: first_touch(rows) for arm, rows in trials.items()},
    "by_approach": {
        name: {
            arm: first_touch([r for r in rows if r["approach"] == index])
            for arm, rows in trials.items()
        }
        for index, name in enumerate(("forward", "square", "cutback"))
    },
    "median_paired_change_s": round(median(delays), 4) if delays else None,
    "paired_shots": len(delays),
    "carry": {
        arm: dict(
            starts=len(rows),
            held=sum(r["held"] for r in rows),
            median_turn_variation=round(median(r["turn_variation"] for r in rows), 4),
            median_lateral_error_mm=round(1000 * median(r["roller_lateral_rms"] for r in rows), 2),
        )
        for arm, rows in carry.items()
    },
}
destination.write_text(json.dumps(findings, indent=2) + "\n")
print(json.dumps(findings, indent=2))
