from dataclasses import asdict, replace
import json
import math
from pathlib import Path
import random

from audit_league import read_game
from roboturk.five_roles import CFG, kickoff
from roboturk.model import Ball, Referee, Robot, RobotKey, World, wrap

source = Path("runs/referee-restarts-v1/match/match")
log, samples = read_game(source)
keys = [RobotKey(*k) for k in log["keys"]]
cases = []
for tick in (311, 927, 1088, 1669, 2261, 2725, 2791):
    poses = samples[tick, 4:].reshape(-1, 3)
    earlier = samples[tick - 1, 4:].reshape(-1, 3)
    robots = tuple(
        Robot(key, x, y, yaw, (x - px) / CFG.dt, (y - py) / CFG.dt, wrap(yaw - pyaw) / CFG.dt)
        for key, (x, y, yaw), (px, py, pyaw) in zip(keys, poses, earlier, strict=True)
    )
    frame = log["frames"][tick]
    world = World(0, robots, Ball(*samples[tick, :4]), Referee.RUNNING, frame["attack_sign"])
    cases.append(
        dict(seed=tick, kind="archive", frame=tick, initial=asdict(world), roles=frame["roles"])
    )

for seed in range(38800000, 38800024):
    rng = random.Random(seed)
    xx, yy = rng.uniform(-1.25, 1.25), rng.uniform(-0.75, 0.75)
    theta = rng.uniform(-math.pi, math.pi)
    positions = {}
    for team, offset in [("blue", theta), ("yellow", theta + math.pi)]:
        d = rng.uniform(0.148, 0.196)
        key = RobotKey(team, 1)
        positions[key] = (
            xx + d * math.cos(offset),
            yy + d * math.sin(offset),
            wrap(offset + math.pi + rng.uniform(-0.4, 0.4)),
        )
    if seed % 3 == 1:
        offset = theta + math.pi / 2
        positions[RobotKey("blue", 2)] = (
            xx + 0.29 * math.cos(offset),
            yy + 0.29 * math.sin(offset),
            theta,
        )
    if seed % 3 == 2:
        offset = theta - math.pi / 2
        positions[RobotKey("yellow", 2)] = (
            xx + 0.29 * math.cos(offset),
            yy + 0.29 * math.sin(offset),
            theta,
        )
    w = kickoff(seed, "blue", 1 if seed % 2 == 0 else -1)
    positions.update(
        {
            r.key: ((-2.7 if r.key.team == "blue" else 2.7), -1.5 + 0.76 * r.key.id, r.yaw)
            for r in w.robots
            if r.key not in positions
        }
    )
    robots = tuple(Robot(r.key, *positions[r.key]) for r in w.robots)
    ball = Ball(xx, yy, rng.uniform(-0.075, 0.075), rng.uniform(-0.075, 0.075))
    cases.append(
        dict(
            seed=seed,
            kind="fresh",
            initial=asdict(replace(w, robots=robots, ball=ball)),
            roles=None,
        )
    )

Path("runs/crowded-fetch-v1/cases.json").write_text(json.dumps(cases, indent=2) + "\n")
