// Supply two table-operator boundary decisions. TIGERs verifies the resulting physical placements.
const cases = {
  NORMAL_FIRST_HALF: { name: "corner", byTeam: "BLUE", x: -4.5, y: 1.6 },
  NORMAL_SECOND_HALF: { name: "goal kick", byTeam: "YELLOW", x: 4.5, y: -1.6 },
};
const sent = new Set();
const socket = new WebSocket("ws://127.0.0.1:21981/api/control");
socket.onmessage = ({ data }) => {
  const state = JSON.parse(data).matchState;
  if (!state) return;
  if (state.stage === "POST_GAME") socket.close();
  const probe = cases[state.stage];
  if (!probe || sent.has(state.stage) || state.gameState?.type !== "RUNNING") return;
  if (state.command?.type !== "NORMAL_START") return;
  sent.add(state.stage);
  socket.send(JSON.stringify({ change: { addGameEventChange: {gameEvent: {
    type: "BALL_LEFT_FIELD_GOAL_LINE",
    ballLeftFieldGoalLine: { byTeam: probe.byTeam, byBot: 0, location: { x: probe.x, y: probe.y } },
  } } } }));
  console.log(JSON.stringify({ stage: state.stage, ...probe }));
};
socket.onclose = () => { if (sent.size !== 2) process.exitCode = 1; };
