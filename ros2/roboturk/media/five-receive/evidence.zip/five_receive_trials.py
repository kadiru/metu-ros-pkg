"""Native first-touch and release panel using the normal 5v5 role commands."""

from dataclasses import asdict, replace
import json
import math
import os
from pathlib import Path
import random
import traceback

import numpy as np
from controller import Supervisor
from roboturk.continuous_backend import ContinuousWebotsBackend
from roboturk.five_play import open_play
from roboturk.five_receive import FiveReceive, carrying
from roboturk.five_roles import CFG, FiveRoles, Flight, TEAMS, kickoff
from roboturk.model import Ball, RobotKey, body_vector, possession, wrap
from roboturk.open_motion import Steering, observed_velocity
from roboturk.counterpass import MOTOR
from roboturk.carrier_motor import track_roller
from roboturk.three_recipient import move
from roboturk.three_match import snapshot

root = Path(os.environ["FIVE_RECEIVE_ROOT"])
output = Path(os.environ["FIVE_RECEIVE_OUTPUT"])
mode = os.environ.get("FIVE_RECEIVE_MODE", "train")
sim = Supervisor()
backend = ContinuousWebotsBackend(sim, CFG)


def opening(seed):
    rand = random.Random(seed)
    team = TEAMS[(seed // 2) % 2]
    sign = 1 if seed % 2 == 0 else -1
    world = kickoff(seed, team, sign if team == "blue" else -sign)
    receiver = RobotKey(team, 1)
    rival = RobotKey(TEAMS[1 - TEAMS.index(team)], 2)
    lane = (0.24, 1.48, 2.82)[seed % 3] * (1 if seed % 4 < 2 else -1)
    angle = lane if sign > 0 else lane + math.pi
    angle += rand.uniform(-0.36, 0.36)
    vx, vy = math.cos(angle), math.sin(angle)
    cx, cy = sign * rand.uniform(2.29, 3.16), rand.uniform(-1.32, 1.32)
    lateral = rand.uniform(-0.15, 0.15)
    range_m = rand.uniform(0.62, 1.32)
    speed = rand.uniform(1.62, 2.79)
    ball = Ball(cx - range_m * vx, cy - range_m * vy, vx * speed, vy * speed)
    close_side = 1 if seed % 2 else -1
    close_dist = rand.uniform(0.64, 1.14)
    bots = []
    for r in world.robots:
        if r.key == receiver:
            pose = cx + 0.11 * vx - lateral * vy, cy + 0.11 * vy + lateral * vx
            yaw = wrap(angle + math.pi + rand.uniform(-0.60, 0.60))
        elif r.key == rival:
            pose = (
                cx + 0.17 * vx - close_side * close_dist * vy,
                cy + 0.17 * vy + close_side * close_dist * vx,
            )
            yaw = angle
        else:
            pose = sign * (-2.0 if r.key.team == "blue" else -3.0), -1.5 + 0.64 * r.key.id
            yaw = r.yaw
        bots.append(replace(r, x=pose[0], y=pose[1], yaw=yaw))
    closing = rand.uniform(0.18, 0.53)
    return replace(world, robots=tuple(bots), ball=ball), receiver, rival, (cx, cy), closing, angle


def trial(seed, profile, film=None):
    initial, receiver, rival, target, closing, angle = opening(seed)
    world = backend.reset(initial)
    actual_start = asdict(world)
    tactics = FiveRoles()
    tactics.flight = Flight(receiver.team, receiver, target, 2.15)
    previous = {}
    count = 0
    first = stable = shot = goal = bounce = None
    lost = False
    impact_time = None
    approaching = False
    touch_yaw = None
    headings = []
    if film:
        field = sim.getFromDef("FIELD")
        colors = (
            [0.07, 0.23, 1], [1, 0.8, 0.03]
        )
        if world.attack_sign < 0:
            colors = colors[::-1]
        for side, color in zip(("left", "right"), colors, strict=True):
            for part in ("Wall", "Inner"):
                field.getField(f"{side}Goal{part}Color").setSFColor(color)
        sim.getFromDef("CAMERA").getField("position").setSFVec3f([target[0], target[1], 6.0])
        film.mkdir(parents=True, exist_ok=True)
    recv_sign = world.direction(receiver.team)
    for tick in range(68):
        if film and tick % 2 == 0:
            sim.exportImage(str(film / f"{tick // 2:04d}.jpg"), 86)
        observed = observed_velocity(world.robots, previous, CFG.dt)
        previous = {r.key: (r.x, r.y) for r in world.robots}
        out, _, _, _ = open_play(
            world, tactics, weights, observed, steering, receive=profile, smooth_carry=True
        )
        robot, marker = world.robot(receiver), world.robot(rival)
        commands = {receiver: out[receiver]}
        if world.time > 0.16:
            ball = world.ball
            face = math.atan2(ball.y - marker.y, ball.x - marker.x)
            commands[rival] = move(
                marker,
                ball.x - 0.13 * math.cos(face),
                ball.y - 0.13 * math.sin(face),
                face,
                closing,
            )
        headings.append([world.time, robot.yaw, commands[receiver].omega])
        world = backend.step(commands)
        kick = next(
            (
                event
                for event in backend.last_kick_events
                if event[0] == receiver and event[2] >= 3.9
            ),
            None,
        )
        if kick is not None and shot is None:
            shot = kick[1].time
        for sample in backend.last_substep_worlds:
            actor, ball = sample.robot(receiver), sample.ball
            dx, dy = ball.x - actor.x, ball.y - actor.y
            distance = math.hypot(dx, dy)
            outward = ((ball.vx - actor.vx) * dx + (ball.vy - actor.vy) * dy) / max(distance, 0.001)
            before_shot = shot is None or sample.time < shot
            if distance <= CFG.robot_radius + CFG.ball_radius + 0.002 and before_shot:
                if impact_time is None:
                    impact_time = sample.time
                approaching |= outward < -0.15
            if (
                impact_time is not None
                and sample.time - impact_time < 0.24
                and approaching
                and distance > 0.15
                and outward > 0.22
                and before_shot
                and stable is None
            ):
                bounce = sample.time if bounce is None else bounce
            if (
                possession(sample, receiver, CFG)
                and not possession(sample, rival, CFG)
                and before_shot
            ):
                if first is None:
                    first = sample.time
                    target_yaw = math.atan2(-ball.y, recv_sign * 4.5 - ball.x)
                    touch_yaw = abs(wrap(target_yaw - actor.yaw))
                count += 1
                if count * backend.basic_ms >= 160 and stable is None:
                    stable = sample.time
            else:
                if first is not None and stable is None and before_shot and distance > 0.177:
                    lost = True
                count = 0
            if (
                shot is not None
                and sample.time >= shot
                and ball.x * recv_sign > 4.526
                and abs(ball.y) < 0.478
            ):
                goal = sample.time
                break
        if goal is not None:
            if film:
                sim.exportImage(str(film / f"{tick // 2 + 1:04d}.jpg"), 86)
            break
    latency = shot - first if first is not None and shot is not None else None
    # A legitimate quick shot can end the hold early after the policy has registered control.
    controlled = stable is not None or (latency is not None and latency >= 0.078)
    return dict(
        seed=seed,
        approach=seed % 3,
        initial=actual_start,
        input_angle=angle,
        first_touch=first,
        clean_first_touch=controlled and not lost and bounce is None,
        bounce=bounce,
        lost_first_touch=lost,
        controlled=controlled,
        shot=shot,
        shot_latency=latency,
        goal=goal,
        heading_error_at_touch=touch_yaw,
        headings=headings if film else None,
    )


def evaluate(seeds, profiles):
    results = {name: [] for name, _ in profiles}
    selected = os.environ.get("FIVE_RECEIVE_FILM")
    for index, seed in enumerate(seeds):
        order = profiles if index % 2 == 0 else profiles[::-1]
        for name, profile in order:
            film = output / name if selected and seed == int(selected) else None
            row = trial(seed, profile, film)
            results[name].append(row)
            print(
                seed,
                name,
                row["clean_first_touch"],
                row["bounce"],
                row["shot_latency"],
                row["goal"],
                flush=True,
            )
        starts = [results[name][-1]["initial"] for name, _ in profiles]
        assert all(s == starts[0] for s in starts)
    return results


def metrics(trials):
    return dict(
        clean=sum(r["clean_first_touch"] for r in trials),
        rebound=sum(r["bounce"] is not None for r in trials),
        goals=sum(r["goal"] is not None for r in trials),
        quick=sum(r["shot_latency"] is not None and r["shot_latency"] <= 0.65 for r in trials),
    )


def carry_trial(seed, damped):
    rng = random.Random(seed)
    world = kickoff(seed, "blue", 1)
    key = RobotKey("blue", 1)
    yaw = rng.uniform(-1.05, 1.05)
    balls = Ball(CFG.possession_x * math.cos(yaw), CFG.possession_x * math.sin(yaw) + 0.016)
    bots = tuple(
        replace(r, x=0, y=0, yaw=yaw)
        if r.key == key
        else replace(r, x=-3.0 if r.key.team == "blue" else 3.0, y=-1.6 + 0.7 * r.key.id)
        for r in world.robots
    )
    world = backend.reset(replace(world, robots=bots, ball=balls))
    turns, lateral = [], []
    in_grip = True
    for tick in range(42):
        actor = world.robot(key)
        aim = 0.25 + 0.38 * math.sin(2.0 * world.time)
        desired = 0.82 * math.cos(aim), 0.82 * math.sin(aim)
        cmd = (
            carrying(world, actor, desired, aim)
            if damped
            else track_roller(world, actor, desired, 9 * wrap(aim - actor.yaw), MOTOR)
        )
        turns.append(cmd.omega)
        lateral.append(body_vector(world.ball.x - actor.x, world.ball.y - actor.y, actor.yaw)[1])
        world = backend.step({key: cmd})
        in_grip &= all(possession(w, key, CFG) for w in backend.last_substep_worlds)
    return dict(
        seed=seed,
        held=in_grip,
        turn_variation=float(np.sum(np.abs(np.diff(turns)))),
        roller_lateral_rms=float(np.sqrt(np.mean(np.square(lateral)))),
    )


try:
    weights_file = json.loads((root / "policies/recipient_3v3_v1/selectors.json").read_text())
    weights = {team: np.asarray(weights_file[str(901 + i)]) for i, team in enumerate(TEAMS)}
    steering = Steering(**json.loads((root / "policies/open_motion_v1/actor.json").read_text()))
    if mode == "carry":
        seeds = range(38920000, 38920016)
        results = {
            name: [carry_trial(seed, damped) for seed in seeds]
            for name, damped in [("old", False), ("new", True)]
        }
    elif mode == "train":
        candidates = [
            FiveReceive(*p)
            for p in (
                (0.65, 6.0, 0.18),
                (0.65, 11.0, 0.62),
                (0.92, 6.0, 0.18),
                (0.92, 6.0, 0.62),
                (0.92, 11.0, 0.62),
            )
        ]
        profiles = [("baseline", None), *((str(i), p) for i, p in enumerate(candidates))]
        results = evaluate(range(38900000, 38900009), profiles)
        scores = {name: metrics(rows) for name, rows in results.items()}
        order = lambda p: (p["clean"], p["goals"], p["quick"], -p["rebound"])
        winner = max(range(len(candidates)), key=lambda i: order(scores[str(i)]))
        selection = dict(
            seeds=[38900000, 38900008],
            scores=scores,
            candidates=[asdict(p) for p in candidates],
            winner=winner,
        )
        (output / "selection.json").write_text(json.dumps(selection, indent=2) + "\n")
        (output / "policy.json").write_text(json.dumps(asdict(candidates[winner]), indent=2) + "\n")
    elif mode in ("eval", "demo"):
        profile = FiveReceive(
            **json.loads((root / "runs/five-receive-v1/train/policy.json").read_text())
        )
        seeds = (
            range(38910000, 38910030) if mode == "eval" else [int(os.environ["FIVE_RECEIVE_FILM"])]
        )
        results = evaluate(seeds, [("baseline", None), ("trained", profile)])
    (output / "trials.json").write_text(json.dumps(results, indent=2) + "\n")
    sim.simulationQuit(0)
except Exception:
    traceback.print_exc()
    sim.simulationQuit(1)
